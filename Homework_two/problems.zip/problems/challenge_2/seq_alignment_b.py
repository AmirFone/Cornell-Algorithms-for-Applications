'''
Challenge 2b
'''

def sequence_align(x, y, c, delta) -> list:
    pass


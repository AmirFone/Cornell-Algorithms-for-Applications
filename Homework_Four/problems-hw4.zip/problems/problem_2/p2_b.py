def binary_search(packages, boxes):
  pass
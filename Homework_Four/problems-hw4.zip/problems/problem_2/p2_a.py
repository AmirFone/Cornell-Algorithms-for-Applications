def linear_search(packages, boxes):
  pass
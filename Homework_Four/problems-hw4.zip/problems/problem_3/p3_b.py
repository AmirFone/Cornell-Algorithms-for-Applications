def  local_search_2opt(cost_matrix, candidate):
  pass
      
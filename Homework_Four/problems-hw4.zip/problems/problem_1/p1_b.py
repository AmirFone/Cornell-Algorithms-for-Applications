def count_min_sketch(a, b, w, p, stream):
  pass
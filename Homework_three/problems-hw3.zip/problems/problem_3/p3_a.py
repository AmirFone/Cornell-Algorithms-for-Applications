# Problem 3

def find_paths(n, paths):
    pass
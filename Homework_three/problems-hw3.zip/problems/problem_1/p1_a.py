# Problem 1a

def is_bipartite(g_l):
    pass
# Problem 1b

def maximal_bipartite_match(g) -> int:
    pass
'''
Challenge 1
'''

def cards_game(m, n, k, counts):
    pass
